import appointments from './appointment';

export = { appointments };
