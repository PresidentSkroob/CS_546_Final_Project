import appointments from './appointments';
import reviews from './reviews';
import users from './users';
import discounts from './discounts';
export = { appointments, reviews, users, discounts };
